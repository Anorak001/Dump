import java.util.List;
import java.util.Scanner;

public class LibraryMenu {
    private Library library;
    private UserInteractionLogger logger = new UserInteractionLogger();
    private LibrarySerializer serializer = new LibrarySerializer();  // Added serializer

    public LibraryMenu(Library library) {
        this.library = library;

        // Load the library data when the program starts
        List<Book> books = serializer.loadLibrary("src/resources/data/library.ser");
        if (books != null) {
            library.setBooks(books);
            System.out.println("Library loaded successfully.");
        } else {
            System.out.println("No saved library found. Loading default books.");
            library.loadBooks("src/resources/data/books.txt");
        }
    }

    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nLibrary Menu:");
            System.out.println("1. View all books");
            System.out.println("2. Sort books by title");
            System.out.println("3. Sort books by author");
            System.out.println("4. Sort books by publication year");
            System.out.println("5. Search for a book by keyword");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    logger.logViewAllBooks();
                    library.viewAllBooks();
                    break;
                case "2":
                    SortUtil.bubbleSort(library.getBooks(), (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
                    logger.logSort("title");
                    System.out.println("Books sorted by title:");
                    library.viewAllBooks();
                    break;
                case "3":
                    SortUtil.insertionSort(library.getBooks(), (b1, b2) -> b1.getAuthor().compareToIgnoreCase(b2.getAuthor()));
                    logger.logSort("author");
                    System.out.println("Books sorted by author:");
                    library.viewAllBooks();
                    break;
                case "4":
                    SortUtil.quickSort(library.getBooks(), (b1, b2) -> Integer.compare(b1.getPublicationYear(), b2.getPublicationYear()), 0, library.getBooks().size() - 1);
                    logger.logSort("publication year");
                    System.out.println("Books sorted by publication year:");
                    library.viewAllBooks();
                    break;
                case "5":
                    System.out.print("Enter a keyword to search: ");
                    String keyword = scanner.nextLine();
                    logger.logSearch(keyword);
                    Book found = library.searchBookByKeyword(keyword);
                    if (found != null) {
                        System.out.println("Book found: " + found);
                    } else {
                        System.out.println("No matching book found.");
                    }
                    break;
                case "6":
                    logger.log("Exited the program");
                    // Save library state before exiting
                    serializer.saveLibrary(library.getBooks(), "src/resources/data/library.ser");
                    System.out.println("Exiting the program. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

}
